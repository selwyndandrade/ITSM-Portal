﻿using System.ComponentModel.DataAnnotations;

namespace ITSM.Portal.API.Models
{
    public class Ticket
    {
        public int Id { get; set; }


        [Required]
        public string Title { get; set; } = string.Empty;


        public string Description { get; set; } = string.Empty;


        public string Status { get; set; } = "Open";


        public string Priority { get; set; } = "Medium";


        public string CreatedBy { get; set; } = string.Empty;


        public string AssignedTo { get; set; } = string.Empty;


        public DateTime CreatedDate { get; set; }


        public List<TicketComment> Comments { get; set; } = new List<TicketComment>();
    }
}